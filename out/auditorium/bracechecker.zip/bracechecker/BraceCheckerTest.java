package auditorium.bracechecker;

public class BraceCheckerTest {

    public static void main (String[] args) {


    }

    //TODO Add test method for BraceChecker's parse method call it from main method
}
